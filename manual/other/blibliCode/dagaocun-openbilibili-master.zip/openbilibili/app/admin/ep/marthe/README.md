# Marthe-service

# 项目简介
### 背景/Background
* 目前移动端crash信息会上报到bugly，bugly系统查询数据比较慢且没有足够的数据分析功能，影响开发查询分析crash的效率
* 目前项目需求bug等信息记录在tapd, 同样tapd系统现有的报表功能并不满足我们PMO的需求，使PMO拿不到充足的数据做分析
* 于是Marthe项目为了解决这些问题孕育而生

### 概览／Overview
* Marthe会根据开发和测试的需求，从bugly拉取原始数据并进行二次处理


# 编译环境


# 依赖包


# 编译执行
